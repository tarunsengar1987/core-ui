const db = require("../models");
const Classes = db.classes;

exports.createClasses = (req, res) => {
    Classes.create({
        name: req.body.name,
        description: req.body.description,
        status: req.body.status
    })
        .then(classes => {
            res.send(classes);
        })
        .catch(err => {
            res.status(500).send({
                message:
                    err.message || "Some error occurred while creating the Classes.",
            });
        });
};

// get All Classes 
exports.getClasses = (req, res) => {

    Classes.findAll()
        .then((data) => {
            res.send(data);
        })
        .catch((err) => {
            res.status(500).send({
                message:
                    err.message || "Some error occurred while creating the Classes.",
            });
        });
};
//update user
exports.updateUser = (req, res) => {
    const id = req.params.id;
    Classes.update(req.body, {
        where: { id: id }
    })
        .then(num => {
            if (num == 1) {
                res.send({
                    message: "Classes was updated successfully."
                });
            } else {
                res.send({
                    message: `Cannot update classes with id=${id}. Maybe User was not found or req.body is empty!`
                });
            }
        })
        .catch(err => {
            res.status(500).send({
                message: "Error updating classes with id=" + id
            });
        });
};

//delete Classes
exports.delete = (req, res) => {
    const id = req.params.id;

    Classes.destroy({
        where: { id: id }
    })
        .then(num => {
            if (num == 1) {
                res.send({
                    message: "Classes was deleted successfully!"
                });
            } else {
                res.send({
                    message: `Cannot delete classes with id=${id}. Maybe Classes was not found!`
                });
            }
        })
        .catch(err => {
            res.status(500).send({
                message: "Could not delete classes with id=" + id
            });
        });
};