var nodemailer = require('nodemailer');

var transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'shreyad.brainerhub@gmail.com',
    pass: 'yijrpevsgpiooaqo'
  }
});

//Send mail to user
sendMaiOfUser = (user,password) => {
    console.log(user)
    var link = "http://localhost:3000/confirm/"+user.id
    var email = user.email
    console.log("password",password)
    var mailOptions = {
        from: 'shreyad.brainerhub@gmail.com',
        to: 'komalv.brainerhub@gmail.com',
        subject: 'Sending Email using Node.js',
        html: '<h2 style="color:#ff6600;">Hello!'+ user.username+' </h2><a href='+link+'>Please click to verifty Your account</a><p>Email:-'+email+'</p><p>Password:-'+password+'</p>'
       ,
      };
      transporter.sendMail(mailOptions, function(error, info){
        if (error) {
            console.log("error==>",error);
          console.log(error);
        } else {
          console.log('Email sent: ' + info.response);
        }
      });
  };

const mail = {
    sendMaiOfUser: sendMaiOfUser
  };
  
module.exports = mail;

