const classController = require("../controllers/class.controller");

module.exports = function (app) {
    app.use(function (req, res, next) {
        res.header(
            "Access-Control-Allow-Headers",
            "x-access-token, Origin, Content-Type, Accept"
        );
        next();
    });

    //All User get route
    app.get("/api/auth/classes", classController.getClasses);

    //Create Classes
    app.post("/api/auth/class", classController.createClasses);

    //Classes update route
    app.put("/api/auth/class/:id", classController.updateUser);

    //Classes delete
    app.delete("/api/auth/class/:id", classController.delete);
};