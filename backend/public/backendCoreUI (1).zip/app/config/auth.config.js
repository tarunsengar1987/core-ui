// JWT token secretkey
module.exports = {
  secret: "bezkoder-secret-key"
};
